import React,{useEffect,useState} from "react";
import {Routes,Route,Navigate,Link,useNavigate,useLocation} from "react-router-dom";
import {LayoutDashboard,Package,ShoppingCart,Boxes,LogOut,Menu,Users} from "lucide-react";
import api from "./api";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Products from "./pages/Products";
import Orders from "./pages/Orders";
import Stock from "./pages/Stock";

function Protected({children}){return localStorage.getItem("token")?children:<Navigate to="/login"/>}

function Layout({children}){
 const nav=useNavigate(),loc=useLocation(),[open,setOpen]=useState(false);
 const logout=()=>{localStorage.clear();nav("/login")};
 const links=[["/","Dashboard",LayoutDashboard],["/products","Products",Package],["/orders","Orders",ShoppingCart],["/stock","Stock",Boxes]];
 return <div className="app"><aside className={open?"sidebar open":"sidebar"}><h2>StockFlow</h2><p className="muted">Inventory Management</p>{links.map(([to,n,I])=><Link onClick={()=>setOpen(false)} className={loc.pathname===to?"nav active":"nav"} to={to} key={to}><I size={18}/>{n}</Link>)}<button className="logout" onClick={logout}><LogOut size={18}/> Logout</button></aside><main className="main"><header><button className="mobile" onClick={()=>setOpen(!open)}><Menu/></button><div><b>Smart Inventory Management</b><span className="muted"> • Full Stack Dashboard</span></div></header>{children}</main></div>
}

export default function App(){
 return <Routes><Route path="/login" element={<Login/>}/><Route path="*" element={<Protected><Layout><Routes><Route path="/" element={<Dashboard/>}/><Route path="/products" element={<Products/>}/><Route path="/orders" element={<Orders/>}/><Route path="/stock" element={<Stock/>}/></Routes></Layout></Protected>}/></Routes>
}
