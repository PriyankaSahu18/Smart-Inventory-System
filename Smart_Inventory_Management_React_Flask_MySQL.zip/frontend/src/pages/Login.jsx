import React,{useState} from "react"; import {useNavigate} from "react-router-dom"; import api from "../api";
export default function Login(){
 const [form,setForm]=useState({email:"admin@inventory.com",password:"Admin@123"}),[err,setErr]=useState(""); const nav=useNavigate();
 const submit=async e=>{e.preventDefault();try{const r=await api.post("/auth/login",form);localStorage.setItem("token",r.data.token);localStorage.setItem("user",JSON.stringify(r.data.user));nav("/")}catch(x){setErr(x.response?.data?.message||"Login failed")}};
 return <div className="login"><div className="login-card"><h1>StockFlow</h1><p className="muted">Smart Inventory Management</p>{err&&<div className="error">{err}</div>}<form onSubmit={submit}><label>Email<input value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>Password<input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/></label><button className="primary">Sign in</button></form><small>Demo: admin@inventory.com / Admin@123</small></div></div>
}
